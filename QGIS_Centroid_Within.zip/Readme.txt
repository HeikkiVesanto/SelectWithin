For the difference between centroid and point on surface see:
http://workshops.boundlessgeo.com/postgis-intro/geometry_returning.html#st-centroid-st-pointonsurface

A good guide can also be found at:
http://gisforthought.com/centroid-within-selection-in-qgis/